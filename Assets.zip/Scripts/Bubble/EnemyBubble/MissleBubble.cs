using UnityEngine;

public class MissileBubble : MonoBehaviour
{
    private float speedX = 1f; // ˮƽ�ƶ�����ٶ�
    private float speedY = 0.2f; // ��ֱ�ƶ�����ٶ�

    public GameObject player;
    private Rigidbody2D rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        player = GameObject.FindWithTag("Player");

        // ȷ���� Kinematic
        rb.bodyType = RigidbodyType2D.Kinematic;

        if (player == null)
        {
            player = GameObject.FindWithTag("Player");
        }
    }

    private void FixedUpdate()
    {
        if (player == null) return;

        // ��ǰˮƽλ��
        Vector2 currentPos = rb.position;

        // Ŀ��ˮƽλ��
        float targetX = player.transform.position.x;
        float targetY = player.transform.position.y;

        // �� speed �����ƶ�����
        float newX = Mathf.MoveTowards(currentPos.x, targetX, speedX * Time.fixedDeltaTime);
        float newY = Mathf.MoveTowards(currentPos.y, targetY, speedY * Time.fixedDeltaTime);

        // �����µ�λ�ã�ֻ�ı� X
        rb.MovePosition(new Vector2(newX, newY));
    }
}
